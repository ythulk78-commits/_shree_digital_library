import { v4 as uuidv4 } from 'uuid';
import type { Student, Seat, FeeRecord, Payment, AttendanceRecord, Notice, Complaint, ActivityLog, Admin, LibrarySettings } from './types';

const STORAGE_KEYS = {
  STUDENTS: '@library_students',
  SEATS: '@library_seats',
  FEES: '@library_fees',
  PAYMENTS: '@library_payments',
  ATTENDANCE: '@library_attendance',
  NOTICES: '@library_notices',
  COMPLAINTS: '@library_complaints',
  ACTIVITY_LOG: '@library_activity_log',
  ADMINS: '@library_admins',
  SETTINGS: '@library_settings',
  CURRENT_USER: '@library_current_user',
  THEME: '@library_theme',
  DARK_MODE: '@library_dark_mode',
  LANGUAGE: '@library_language',
};

// Default Settings
export const defaultSettings: LibrarySettings = {
  name: 'My Library',
  address: '123 Knowledge Street',
  phone: '+91 98765 43210',
  defaultFee: 1500,
  gracePeriod: 7,
  autoReleaseDays: 5,
  morningStart: '08:00',
  morningEnd: '12:00',
  eveningStart: '14:00',
  eveningEnd: '20:00',
  openTime: '07:00',
  closeTime: '22:00',
};

// Default Admin
export const defaultAdmins: Admin[] = [
  {
    id: uuidv4(),
    name: 'Library Owner',
    email: 'admin@library.com',
    password: 'admin123',
    role: 'owner',
    createdAt: new Date().toISOString(),
  },
];

// Generate sample seats (grid)
export function generateSampleSeats(): Seat[] {
  const seats: Seat[] = [];
  const rows = 4;
  const cols = 6;
  
  for (let r = 1; r <= rows; r++) {
    for (let c = 1; c <= cols; c++) {
      seats.push({
        id: uuidv4(),
        label: `S${r}${String(c).padStart(2, '0')}`,
        row: r,
        col: c,
        status: 'available',
        isLabel: false,
      });
    }
  }
  
  // Add labels
  seats.push(
    { id: uuidv4(), label: '🚪 EXIT', row: 0, col: 0, status: 'available', isLabel: true },
    { id: uuidv4(), label: '📚 Books', row: 0, col: 7, status: 'available', isLabel: true }
  );
  
  return seats;
}

// Sample students for demo
export function generateSampleStudents(): Student[] {
  return [
    {
      id: uuidv4(),
      name: 'Rahul Sharma',
      mobile: '9876543210',
      password: 'pass123',
      seatId: undefined,
      batch: 'morning',
      joinedDate: new Date().toISOString(),
      totalStudyHours: 45,
      acceptedRules: true,
      isActive: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: uuidv4(),
      name: 'Priya Patel',
      mobile: '9876543211',
      password: 'pass123',
      seatId: undefined,
      batch: 'evening',
      joinedDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      totalStudyHours: 120,
      acceptedRules: true,
      isActive: true,
      createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: uuidv4(),
      name: 'Amit Kumar',
      mobile: '9876543212',
      password: 'pass123',
      seatId: undefined,
      batch: 'full_day',
      joinedDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
      totalStudyHours: 78,
      acceptedRules: true,
      isActive: true,
      createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
    },
  ];
}

// Sample notices
export function generateSampleNotices(): Notice[] {
  return [
    {
      id: uuidv4(),
      title: '🎉 Welcome to My Library!',
      message: 'Welcome to our digital library management system. Please check your dashboard regularly.',
      type: 'general',
      isActive: true,
      createdAt: new Date().toISOString(),
      readBy: [],
    },
    {
      id: uuidv4(),
      title: '⚠️ Holiday Notice',
      message: 'Library will remain closed on 26th January (Republic Day).',
      type: 'holiday',
      isActive: true,
      createdAt: new Date().toISOString(),
      readBy: [],
    },
    {
      id: uuidv4(),
      title: '🔴 Urgent: Fee Reminder',
      message: 'Please clear your pending fees before the due date to avoid late charges.',
      type: 'urgent',
      isActive: true,
      createdAt: new Date().toISOString(),
      readBy: [],
    },
  ];
}

export { STORAGE_KEYS };
