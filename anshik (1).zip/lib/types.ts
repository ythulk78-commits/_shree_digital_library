export type UserRole = 'admin' | 'student';
export type SeatStatus = 'available' | 'reserved' | 'partial' | 'due' | 'maintenance';
export type BatchType = 'morning' | 'evening' | 'full_day';
export type FeeStatus = 'paid' | 'due' | 'overdue' | 'partial';
export type PaymentMethod = 'cash' | 'upi' | 'bank_transfer';
export type NoticeType = 'urgent' | 'holiday' | 'general';
export type ComplaintType = 'ac' | 'noise' | 'seating' | 'cleanliness' | 'other';
export type ComplaintStatus = 'submitted' | 'in_progress' | 'resolved';

export interface Admin {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'owner' | 'sub_admin';
  permissions?: string[];
  createdAt: string;
}

export interface Student {
  id: string;
  name: string;
  mobile: string;
  password: string;
  seatId?: string;
  batch?: BatchType;
  joinedDate: string;
  totalStudyHours: number;
  acceptedRules: boolean;
  isActive: boolean;
  createdAt: string;
}

export interface Seat {
  id: string;
  label: string;
  row: number;
  col: number;
  status: SeatStatus;
  morningStudentId?: string;
  eveningStudentId?: string;
  fullDayStudentId?: string;
  isLabel: boolean;
}

export interface FeeRecord {
  id: string;
  studentId: string;
  amount: number;
  paidAmount: number;
  dueDate: string;
  paidDate?: string;
  status: FeeStatus;
  month: string;
  year: number;
  penalty?: number;
  paymentMethod?: PaymentMethod;
  createdAt: string;
}

export interface Payment {
  id: string;
  feeRecordId: string;
  studentId: string;
  amount: number;
  method: PaymentMethod;
  date: string;
  notes?: string;
  createdAt: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  date: string;
  checkIn?: string;
  checkOut?: string;
  totalMinutes: number;
  createdAt: string;
}

export interface Notice {
  id: string;
  title: string;
  message: string;
  type: NoticeType;
  isActive: boolean;
  createdAt: string;
  readBy: string[];
}

export interface Complaint {
  id: string;
  studentId: string;
  type: ComplaintType;
  description: string;
  status: ComplaintStatus;
  adminResponse?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  details: string;
  timestamp: string;
}

export interface LibrarySettings {
  name: string;
  address: string;
  phone: string;
  defaultFee: number;
  gracePeriod: number;
  autoReleaseDays: number;
  morningStart: string;
  morningEnd: string;
  eveningStart: string;
  eveningEnd: string;
  openTime: string;
  closeTime: string;
}

export interface PomodoroSession {
  id: string;
  studentId: string;
  startTime: string;
  endTime?: string;
  duration: number;
  completed: boolean;
  createdAt: string;
}
