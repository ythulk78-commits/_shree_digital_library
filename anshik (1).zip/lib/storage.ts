import AsyncStorage from '@react-native-async-storage/async-storage';
import { STORAGE_KEYS, defaultAdmins, defaultSettings, generateSampleSeats, generateSampleStudents, generateSampleNotices } from './data';
import type { Student, Seat, FeeRecord, Payment, AttendanceRecord, Notice, Complaint, ActivityLog, Admin, LibrarySettings } from './types';

// Generic storage helpers
export async function getItem<T>(key: string): Promise<T | null> {
  try {
    const value = await AsyncStorage.getItem(key);
    return value ? JSON.parse(value) : null;
  } catch {
    return null;
  }
}

export async function setItem<T>(key: string, value: T): Promise<void> {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('Storage set error:', error);
  }
}

export async function removeItem(key: string): Promise<void> {
  try {
    await AsyncStorage.removeItem(key);
  } catch (error) {
    console.error('Storage remove error:', error);
  }
}

// Initialize data if not exists
export async function initializeData(): Promise<void> {
  try {
    let admins = await getItem<Admin[]>(STORAGE_KEYS.ADMINS);
    if (!admins || admins.length === 0) {
      await setItem(STORAGE_KEYS.ADMINS, defaultAdmins);
    }

    let settings = await getItem<LibrarySettings>(STORAGE_KEYS.SETTINGS);
    if (!settings) {
      await setItem(STORAGE_KEYS.SETTINGS, defaultSettings);
    }

    let seats = await getItem<Seat[]>(STORAGE_KEYS.SEATS);
    if (!seats || seats.length === 0) {
      await setItem(STORAGE_KEYS.SEATS, generateSampleSeats());
    }

    let students = await getItem<Student[]>(STORAGE_KEYS.STUDENTS);
    if (!students || students.length === 0) {
      await setItem(STORAGE_KEYS.STUDENTS, generateSampleStudents());
    }

    let notices = await getItem<Notice[]>(STORAGE_KEYS.NOTICES);
    if (!notices || notices.length === 0) {
      await setItem(STORAGE_KEYS.NOTICES, generateSampleNotices());
    }

    // Initialize empty arrays
    let fees = await getItem<FeeRecord[]>(STORAGE_KEYS.FEES);
    if (!fees) await setItem(STORAGE_KEYS.FEES, []);

    let payments = await getItem<Payment[]>(STORAGE_KEYS.PAYMENTS);
    if (!payments) await setItem(STORAGE_KEYS.PAYMENTS, []);

    let attendance = await getItem<AttendanceRecord[]>(STORAGE_KEYS.ATTENDANCE);
    if (!attendance) await setItem(STORAGE_KEYS.ATTENDANCE, []);

    let complaints = await getItem<Complaint[]>(STORAGE_KEYS.COMPLAINTS);
    if (!complaints) await setItem(STORAGE_KEYS.COMPLAINTS, []);

    let activityLog = await getItem<ActivityLog[]>(STORAGE_KEYS.ACTIVITY_LOG);
    if (!activityLog) await setItem(STORAGE_KEYS.ACTIVITY_LOG, []);
  } catch (error) {
    console.error('Init error:', error);
  }
}

// Data access functions
export async function getStudents(): Promise<Student[]> {
  return getItem<Student[]>(STORAGE_KEYS.STUDENTS) || [];
}

export async function saveStudents(students: Student[]): Promise<void> {
  await setItem(STORAGE_KEYS.STUDENTS, students);
}

export async function getSeats(): Promise<Seat[]> {
  return getItem<Seat[]>(STORAGE_KEYS.SEATS) || [];
}

export async function saveSeats(seats: Seat[]): Promise<void> {
  await setItem(STORAGE_KEYS.SEATS, seats);
}

export async function getFees(): Promise<FeeRecord[]> {
  return getItem<FeeRecord[]>(STORAGE_KEYS.FEES) || [];
}

export async function saveFees(fees: FeeRecord[]): Promise<void> {
  await setItem(STORAGE_KEYS.FEES, fees);
}

export async function getPayments(): Promise<Payment[]> {
  return getItem<Payment[]>(STORAGE_KEYS.PAYMENTS) || [];
}

export async function savePayments(payments: Payment[]): Promise<void> {
  await setItem(STORAGE_KEYS.PAYMENTS, payments);
}

export async function getAttendance(): Promise<AttendanceRecord[]> {
  return getItem<AttendanceRecord[]>(STORAGE_KEYS.ATTENDANCE) || [];
}

export async function saveAttendance(attendance: AttendanceRecord[]): Promise<void> {
  await setItem(STORAGE_KEYS.ATTENDANCE, attendance);
}

export async function getNotices(): Promise<Notice[]> {
  return getItem<Notice[]>(STORAGE_KEYS.NOTICES) || [];
}

export async function saveNotices(notices: Notice[]): Promise<void> {
  await setItem(STORAGE_KEYS.NOTICES, notices);
}

export async function getComplaints(): Promise<Complaint[]> {
  return getItem<Complaint[]>(STORAGE_KEYS.COMPLAINTS) || [];
}

export async function saveComplaints(complaints: Complaint[]): Promise<void> {
  await setItem(STORAGE_KEYS.COMPLAINTS, complaints);
}

export async function getActivityLog(): Promise<ActivityLog[]> {
  return getItem<ActivityLog[]>(STORAGE_KEYS.ACTIVITY_LOG) || [];
}

export async function saveActivityLog(log: ActivityLog[]): Promise<void> {
  await setItem(STORAGE_KEYS.ACTIVITY_LOG, log);
}

export async function getAdmins(): Promise<Admin[]> {
  return getItem<Admin[]>(STORAGE_KEYS.ADMINS) || [];
}

export async function saveAdmins(admins: Admin[]): Promise<void> {
  await setItem(STORAGE_KEYS.ADMINS, admins);
}

export async function getSettings(): Promise<LibrarySettings> {
  return (await getItem<LibrarySettings>(STORAGE_KEYS.SETTINGS)) || defaultSettings;
}

export async function saveSettings(settings: LibrarySettings): Promise<void> {
  await setItem(STORAGE_KEYS.SETTINGS, settings);
}

export async function addActivityLog(entry: Omit<ActivityLog, 'id' | 'timestamp'>): Promise<void> {
  const logs = await getActivityLog();
  logs.unshift({
    ...entry,
    id: Math.random().toString(36).substr(2, 9),
    timestamp: new Date().toISOString(),
  });
  await saveActivityLog(logs.slice(0, 500)); // Keep last 500 entries
}
